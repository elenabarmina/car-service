CREATE FUNCTION newid () RETURNS uuid
	LANGUAGE sql
AS $$
select md5(random()::text || clock_timestamp()::text)::uuid
$$
